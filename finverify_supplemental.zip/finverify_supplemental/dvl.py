"""
dvl.py — Deterministic Verification Layer (DVL)
================================================
Inference-time numerical correction for financial LLMs.
No ground truth used at inference; all rules fire on
prediction value, question keywords, and document headers.

Paper: "Structured Numerical Hallucinations in Financial LLMs:
        Deterministic Verification Outperforms Chain-of-Thought Prompting"
"""

import re
import math
from typing import Optional, Tuple

# ── Keyword sets (fixed pre-evaluation) ─────────────────────────────────────

RATIO_KEYWORDS = {
    "ratio", "margin", "return", "yield", "percent", "percentage",
    "change", "growth", "increase", "decrease", "loss", "rate"
}

NEGATION_KEYWORDS = {
    "decrease", "loss", "declined", "negative", "fell",
    "drop", "reduced", "down"
}

MAGNITUDE_FACTORS = [0.001, 0.01, 0.1, 10, 100, 1000]

UNIT_PATTERNS = {
    r"in\s+millions":  1e6,
    r"in\s+thousands": 1e3,
    r"in\s+billions":  1e9,
    r"(?:percent|%)\b": 1e-2,
}


# ── Helpers ──────────────────────────────────────────────────────────────────

def extract_number(text: str) -> Optional[float]:
    """Extract first parseable number from model output (first 100 chars)."""
    if not text:
        return None
    text = text[:100].replace("$", "").replace(",", "").replace("%", "")
    text = re.sub(r'\((\d+\.?\d*)\)', r'-\1', text)
    matches = re.findall(r"[-+]?\d*\.?\d+", text)
    try:
        return float(matches[0]) if matches else None
    except (ValueError, IndexError):
        return None


def is_correct(pred: Optional[float], actual: float, tol: float = 0.05) -> bool:
    """5% relative tolerance — matches FinQA evaluation protocol."""
    if pred is None:
        return False
    if actual == 0:
        return abs(pred) < 0.01
    return abs(pred - actual) / abs(actual) <= tol


def _is_ratio_question(question: str) -> bool:
    q = question.lower()
    return any(kw in q for kw in RATIO_KEYWORDS)


def _has_negation(question: str) -> bool:
    q = question.lower()
    return any(kw in q for kw in NEGATION_KEYWORDS)


def _parse_unit_header(doc_text: str) -> Optional[float]:
    """
    Scan first 500 chars of document for unit-scale markers.
    Returns the unit as a float (e.g. 1e6 for 'in millions'),
    or None if no pattern matches.
    """
    snippet = doc_text[:500].lower()
    for pattern, unit in UNIT_PATTERNS.items():
        if re.search(pattern, snippet):
            return unit
    return None


def _magnitude_inconsistent(y_hat: float, unit: float) -> bool:
    """True if |log10(|y_hat|) - log10(unit)| > 1.5."""
    if y_hat == 0:
        return False
    return abs(math.log10(abs(y_hat)) - math.log10(unit)) > 1.5


# ── DVL: inference mode (Algorithm 1 in paper) ───────────────────────────────

def apply_dvl(
    question: str,
    y_hat: Optional[float],
    doc_text: str = ""
) -> Tuple[Optional[float], str]:
    """
    Deterministic Verification Layer — inference mode.

    Parameters
    ----------
    question : str   — the financial question
    y_hat    : float — raw model prediction (may be None)
    doc_text : str   — document context (pre-text + table)

    Returns
    -------
    (y_star, correction_type)
        y_star          : corrected prediction (or y_hat if no rule fires)
        correction_type : one of 'scale_div100', 'scale_mul100',
                          'sign_corrected', 'magnitude_<k>', 'unchanged', 'no_pred'
    """
    if y_hat is None:
        return None, "no_pred"

    y_star = y_hat
    log_entries = []

    # ── Rule 1: Scale correction ─────────────────────────────────────────────
    if _is_ratio_question(question):
        if abs(y_star) > 100:
            y_star = y_star / 100
            log_entries.append("scale_div100")
        elif abs(y_star) < 1:
            y_star = y_star * 100
            log_entries.append("scale_mul100")

    # ── Rule 2: Sign correction ──────────────────────────────────────────────
    if _has_negation(question) and y_star > 0:
        y_star = -y_star
        log_entries.append("sign_corrected")

    # ── Rule 3: Magnitude correction ─────────────────────────────────────────
    unit = _parse_unit_header(doc_text)
    if unit is not None and _magnitude_inconsistent(y_star, unit):
        best_k = min(
            MAGNITUDE_FACTORS,
            key=lambda k: abs(math.log10(abs(y_star * k)) - math.log10(unit))
            if y_star * k != 0 else float("inf")
        )
        y_star = y_star * best_k
        log_entries.append(f"magnitude_{best_k}")

    correction_type = "+".join(log_entries) if log_entries else "unchanged"
    return y_star, correction_type


# ── DVL: evaluation-harness wrapper ─────────────────────────────────────────

def apply_dvl_eval(
    question: str,
    y_hat: Optional[float],
    actual: float,
    doc_text: str = ""
) -> Tuple[Optional[float], str, bool]:
    """
    Evaluation harness: calls apply_dvl(), then checks correctness.
    Ground truth `actual` is NEVER passed into apply_dvl().

    Returns (y_star, correction_type, is_correct_after_dvl)
    """
    y_star, correction_type = apply_dvl(question, y_hat, doc_text)
    return y_star, correction_type, is_correct(y_star, actual)


# ── Quick demo ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    examples = [
        {
            "desc": "Scale (percent → decimal)",
            "question": "What was the gross margin percentage?",
            "y_hat": 27.9,
            "doc": "The following data is presented in millions.",
            "truth": 0.279,
        },
        {
            "desc": "Sign correction",
            "question": "What was the percentage decline in net goodwill?",
            "y_hat": 0.201,
            "doc": "",
            "truth": -0.206,
        },
        {
            "desc": "Magnitude (millions)",
            "question": "What was the total return for E*TRADE Financial?",
            "y_hat": 378.81,
            "doc": "Dollar amounts in millions unless otherwise noted.",
            "truth": 0.378,
        },
    ]

    for ex in examples:
        y_star, ctype = apply_dvl(ex["question"], ex["y_hat"], ex["doc"])
        ok = is_correct(y_star, ex["truth"])
        print(f"[{ex['desc']}]")
        print(f"  y_hat={ex['y_hat']}  →  y_star={y_star:.4f}  "
              f"({'✓' if ok else '✗'}, truth={ex['truth']})  [{ctype}]")
        print()

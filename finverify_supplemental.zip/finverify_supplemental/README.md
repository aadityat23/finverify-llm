# FinVerify — Supplemental Code

Code for: **"Structured Numerical Hallucinations in Financial LLMs:
Deterministic Verification Outperforms Chain-of-Thought Prompting"**

---

## Files

| File | Description |
|------|-------------|
| `dvl.py` | Deterministic Verification Layer — standalone, no dependencies beyond stdlib. Implements Algorithm 1 from the paper. |
| `eval_finqa.ipynb` | Full FinQA evaluation: baseline → +document context → +DVL v1 → +fine-tuning → +DVL v2. Kaggle T4 GPU. |
| `eval_drop.ipynb` | DROP cross-domain evaluation (n=50). Google Colab. |
| `eval_baseline.ipynb` | Baseline (no context) and context-only ablation. Kaggle T4 GPU. |

---

## Setup

```bash
pip install transformers accelerate "bitsandbytes>=0.46.1" peft datasets scipy
```

HuggingFace token required. Set as `HF_TOKEN` in Kaggle Secrets or Colab userdata.

Fine-tuned adapter: `aadi2026/finverify-lora` (HuggingFace Hub)

---

## Running DVL standalone

```python
from dvl import apply_dvl, is_correct

y_hat = 27.9
question = "What was the gross margin percentage?"
doc = "Dollar amounts in millions unless otherwise noted."

y_star, correction_type = apply_dvl(question, y_hat, doc)
print(y_star, correction_type)  # 0.279, scale_div100
```

---

## Reproducibility

All experiments run on a single NVIDIA T4 (16GB VRAM).
- FinQA ablations: ~8 GPU-hours (Kaggle free tier)
- TAT-QA evaluation: ~7 GPU-hours (Kaggle free tier)
- DROP evaluation: ~1 GPU-hour (Google Colab free tier)

FinQA and TAT-QA are publicly available under their respective research licenses.
No proprietary data or compute was used.

---

## AI Assistance Disclosure

AI assistants (Claude, ChatGPT) were used for coding support and writing assistance
during preparation of this work. All experimental design, results, analysis,
and scientific claims are the authors' own.
